<!--
  GitHub Profile README
  Assets are stored in the /assets folder.
-->

<div align="center">

<br/>

<img src="assets/hero-heading.svg" alt="Shubhangi Savant" width="500" />

<br/>

<sub>Computer Science student · frontend developer · building interfaces that feel good to use</sub>

</div>

<br/>

<table>
<tr>

<td width="36%" valign="top" align="center">

<img src="assets/ascii-portrait.svg" alt="ASCII terminal portrait of Shubhangi Savant" width="100%" />

</td>

<td width="64%" valign="top">

<img src="assets/typing.svg" alt="Animated typing introduction" width="100%" />

<br/>

I enjoy turning ideas into clean, interactive web experiences. I like working on interfaces where design and functionality come together naturally — from the overall layout down to the little interactions that make a page feel alive.

<br/>

### Connect

[![GitHub](https://img.shields.io/badge/GitHub-070b14?style=flat-square&logo=github&logoColor=22d3ee)](https://github.com/shubhangi23457)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-070b14?style=flat-square&logo=linkedin&logoColor=3882f6)](https://www.linkedin.com/in/shubhangi-savant-05229041b/)
[![Email](https://img.shields.io/badge/Email-070b14?style=flat-square&logo=gmail&logoColor=7c3aed)](mailto:savant.shubhangi@gmail.com)

</td>

</tr>
</table>

<br/>

## `About Me`

I'm a Computer Science student who enjoys building things for the web and learning how different pieces of technology work together. I especially enjoy frontend development because it gives me a chance to combine logic with creativity and turn an idea into something people can actually interact with.

I like clean layouts, responsive designs, smooth interactions, and understanding what happens behind the interface. I'm also interested in AI/ML and enjoy exploring how programming, data, and intelligent systems can work together.

Right now, I'm focused on improving my problem-solving skills, building practical projects, and becoming a developer who can confidently work across both frontend and backend technologies.

- 🐍 Creator of **SnakeVerse**, a project I keep improving and experimenting with
- 🧩 I prefer understanding *why* something breaks instead of just patching it
- 🌱 Always learning by building projects and exploring new technologies
- 💻 Practicing programming, data structures, algorithms, and web development
- 🎯 Working toward becoming a Full-Stack Developer & AI/ML Engineer

<br/>

## `Tech Stack`

<div align="center">

<img src="assets/tech-stack.svg" alt="Tech stack" width="100%" />

</div>

<br/>

## `GitHub Analytics`

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=shubhangi23457&show_icons=true&theme=tokyonight&hide_border=true" alt="GitHub Stats" height="165"/>

<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=shubhangi23457&layout=compact&theme=tokyonight&hide_border=true" alt="Top Languages" height="165"/>

</div>

<br/>

## `🔥 GitHub Daily Streak`

<!--
  Fully automatic — nothing below is hand-edited.

  .github/workflows/update-github-stats.yml runs scripts/generate_github_stats.py
  once a day (and on every push to main), which:
    1. Queries GitHub's official GraphQL contribution calendar for this account
       (contributionsCollection.contributionCalendar) — no scraping, no
       third-party stats service.
    2. Computes the current streak, longest streak, today's contribution count,
       and the last 14 days of activity from that real data.
    3. Regenerates the two SVGs below and commits them back to the repo only
       when a value actually changed.

  No numbers on this page are hard-coded, random, or manually maintained.
-->

<div align="center">

<img src="assets/github-streak.svg" alt="GitHub daily streak: current streak, longest streak, today's contributions, total contributions, and last 14 days of activity" width="100%"/>

<br/><br/>

<img src="assets/github-contributions.svg" alt="GitHub contribution heatmap, last 12 months" width="100%"/>

<br/>

<sub>Updates automatically every day · powered by <a href="scripts/generate_github_stats.py">scripts/generate_github_stats.py</a> + <a href=".github/workflows/update-github-stats.yml">GitHub Actions</a></sub>

</div>

<br/>

---

<div align="center">

<sub>Thanks for stopping by — always building, learning, and improving something new.</sub>

</div>