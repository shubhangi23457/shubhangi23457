<!--
  assets/ascii-portrait.svg was generated from your uploaded photo. To
  regenerate it (new photo, tighter crop, different resolution):
      python3 assets/generate_ascii.py your-photo.jpg assets/ascii-portrait.svg \
        --cols 62 --rows 38 --crop 0.12,0.03,0.88,0.85
-->

<div align="center">

<br/>

<img src="assets/hero-heading.svg" alt="Shubhangi Savant" width="500" />

<br/>
<sub>Computer Science student · frontend developer · building interfaces that move</sub>

</div>

<br/>

<table>
<tr>
<td width="36%" valign="top" align="center">

<img src="assets/ascii-portrait.svg" alt="ASCII terminal portrait of Shubhangi Savant" width="100%" />

</td>
<td width="64%" valign="top">

<img src="assets/typing.svg" alt="Animated typing introduction" width="100%" />

<br/>

Frontend developer and Computer Science student who builds expressive, motion-driven interfaces with **React**. I care about interfaces that feel considered, not just functional.

**Connect**

[![GitHub](https://img.shields.io/badge/GitHub-070b14?style=flat-square&logo=github&logoColor=22d3ee)](https://github.com/shubhangi23457)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-070b14?style=flat-square&logo=linkedin&logoColor=3882f6)](https://www.linkedin.com/in/shubhangi-savant-05229041b/)
[![Email](https://img.shields.io/badge/Email-070b14?style=flat-square&logo=gmail&logoColor=7c3aed)](mailto:savant.shubhangi@gmail.com)

</td>
</tr>
</table>

<br/>

## `About Me`

I'm a Computer Science student, and most of my free time goes into building things for the web. What hooked me early on was noticing how much a small detail can change how an interface feels — a hover state that responds just right, a transition that doesn't overshoot. Once I started paying attention to that stuff I couldn't really stop.

These days that means a lot of time in React, figuring out how to make things move without making them feel gimmicky. I'm still early in the "figuring out what kind of developer I want to be" phase, but I know I like being close to the interface — the part people actually touch.

- 🐍 Creator of **SnakeVerse**, a project I keep coming back to and improving
- 🧩 I'd rather understand *why* something broke than just patch it
- 🌱 Always learning — reading other people's code, picking up new tools, leveling up a little at a time
- 🎯 Working toward becoming a well-rounded full-stack developer

<br/>

## `Tech Stack`

<div align="center">

<img src="assets/tech-stack.svg" alt="Tech stack grouped by category: Frontend, Backend, Languages, Database, Tools" width="100%" />

</div>

<br/>

## `GitHub Analytics`

<div align="center">

<img src="https://github-readme-stats.vercel.app/api?username=shubhangi23457&show_icons=true&count_private=true&title_color=22d3ee&text_color=e6f1ff&icon_color=7c3aed&bg_color=070b14&border_color=1e293b&hide_border=false" alt="GitHub Stats" height="165"/>
<img src="https://github-readme-stats.vercel.app/api/top-langs/?username=shubhangi23457&layout=compact&title_color=22d3ee&text_color=e6f1ff&icon_color=3882f6&bg_color=070b14&border_color=1e293b&hide_border=false" alt="Top Languages" height="165"/>

<img src="https://streak-stats.demolab.com/?user=shubhangi23457&background=070b14&ring=39d353&fire=39d353&currStreakLabel=39d353&sideLabels=e6f1ff&currStreakNum=e6f1ff&sideNums=e6f1ff&dates=64748b&stroke=1e293b&border=1e293b" alt="GitHub Streak — total contributions, current streak, and longest streak, pulled live from GitHub"/>

<img src="https://github-profile-trophy.vercel.app/?username=shubhangi23457&theme=tokyonight&no-frame=true&row=1&column=7&margin-w=8&margin-h=8" alt="GitHub Trophies" width="100%"/>

<br/>

<img src="assets/contribution-graph.svg" alt="GitHub contribution calendar for shubhangi23457, GitHub green theme, animated left-to-right reveal" width="100%"/>

</div>

<sub align="center">Streak numbers and the graph above are generated straight from `github.com/users/shubhangi23457/contributions` — nothing is hardcoded. The graph is regenerated daily by <a href="./.github/workflows/update-contribution-graph.yml">a GitHub Action</a> (or run `python3 scripts/generate_contribution_graph.py` yourself) so it always reflects real activity.</sub>
