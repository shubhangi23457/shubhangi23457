#!/usr/bin/env python3
"""
Generates a real-data GitHub contribution graph SVG (official GitHub green
palette, left-to-right reveal animation) plus prints total / current /
longest streak numbers, computed straight from github.com's own public
contributions endpoint (no fake/hardcoded data, no API token required).

Run manually:  python3 scripts/generate_contribution_graph.py <username>
Run in CI:     python3 scripts/generate_contribution_graph.py
               (reads GITHUB_USERNAME env var)
"""
import html
import os
import re
import sys
import urllib.request

USERNAME = sys.argv[1] if len(sys.argv) > 1 else os.environ.get("GITHUB_USERNAME", "shubhangi23457")
OUT_SVG = os.path.join(os.path.dirname(__file__), "..", "assets", "contribution-graph.svg")

# Official GitHub dark-theme contribution palette (level 0-4)
LEVEL_COLORS = ["#161b22", "#0e4429", "#006d32", "#26a641", "#39d353"]
EMPTY_STROKE = "#30363d"
CELL = 11
GAP = 3
STEP = CELL + GAP


def fetch_contributions(username):
    url = f"https://github.com/users/{username}/contributions"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=20) as resp:
        return resp.read().decode("utf-8")


def find_today(html_text, days):
    """
    GitHub's own calendar boundary, not our runtime clock.

    The generator used to call Python's `date.today()` to decide what
    "today" means when walking the streak backwards. That is a real bug:
    a GitHub Action runner's system clock is UTC, but GitHub renders the
    contribution calendar (and buckets each contribution into a day) using
    the profile's own timezone setting when one is configured. Near a day
    boundary those two clocks can disagree by a day, which would make the
    streak walk either skip a real contribution day or count one that
    hasn't "happened" yet on GitHub's calendar.

    Fix: read GitHub's own `data-to="...UTC"` marker straight off the page
    -- that is GitHub's own definition of "today" for this exact calendar,
    so there is no separate clock to get out of sync with. Fall back to
    the newest parsed day only if that marker is ever missing.
    """
    m = re.search(r'data-to="(\d{4}-\d{2}-\d{2})', html_text)
    if m:
        return m.group(1)
    return max(d["date"] for d in days)


def parse_days(html_text):
    """Returns every calendar day as {date, row, col, level, count}."""

    days = []
    for m in re.finditer(
        r'<td[^>]*data-date="([\d-]+)"[^>]*id="contribution-day-component-(\d+)-(\d+)"[^>]*data-level="(\d)"',
        html_text,
    ):
        d, row, col, level = m.group(1), int(m.group(2)), int(m.group(3)), int(m.group(4))
        days.append({"date": d, "row": row, "col": col, "level": level})

    # Counts live in a separate <tool-tip> element tied to the same day id,
    # e.g. "3 contributions on August 12th." / "1 contribution on May 1st."
    # / "No contributions on June 3rd." Matched independently of the <td>
    # regex above (and independently of `level`) so a count is never
    # derived by assuming a fixed word count, singular/plural wording, or
    # thousands separators -- all of that is normalised below instead of
    # being baked into the match itself.
    count_map = {}
    for m in re.finditer(
        r'for="contribution-day-component-(\d+-\d+)"[^>]*>\s*([^<]+?)\s*</tool-tip>', html_text
    ):
        key = m.group(1)
        text = html.unescape(m.group(2)).replace("\xa0", " ").strip()
        if text.lower().startswith("no contributions"):
            count_map[key] = 0
            continue
        # "1 contribution on ..." / "12 contributions on ..." /
        # "1,024 contributions on ..." -- leading digits (with optional
        # thousands separators) are the count; everything else is prose.
        num_match = re.match(r"([\d,]+)", text)
        if num_match:
            count_map[key] = int(num_match.group(1).replace(",", ""))
        # if a tooltip ever fails to match (e.g. GitHub changes the
        # phrasing), we deliberately do NOT default it to 0 here -- see
        # the reconciliation pass below, which treats a missing count as
        # "unknown" rather than silently pretending it was zero.

    for d in days:
        key = f"{d['row']}-{d['col']}"
        if key in count_map:
            d["count"] = count_map[key]
        elif d["level"] == 0:
            # No tooltip matched, but GitHub's own level says "empty" --
            # 0 is genuinely correct here, not a guess.
            d["count"] = 0
        else:
            # Level says this day had activity but we couldn't read the
            # exact number from its tooltip. Do not invent a number --
            # surface it loudly so it gets fixed instead of silently
            # showing an inaccurate count.
            raise ValueError(
                f"Could not read a contribution count for {d['date']} "
                f"(level={d['level']}, row={d['row']}, col={d['col']}). "
                "Refusing to guess a value -- check tool-tip parsing."
            )

    days.sort(key=lambda d: d["date"])
    return days


def compute_streaks(days, today):
    total = sum(d["count"] for d in days)

    longest = 0
    running = 0
    for d in days:
        if d["date"] > today:
            continue  # future placeholder days aren't real yet
        if d["count"] > 0:
            running += 1
            longest = max(longest, running)
        else:
            running = 0

    current = 0
    for d in reversed(days):
        if d["date"] > today:
            continue  # future placeholder days aren't real yet
        if d["count"] > 0:
            current += 1
        elif d["date"] == today:
            # Today can still be 0 without breaking the streak -- the day
            # isn't over yet, so we look at yesterday instead of stopping.
            continue
        else:
            break  # a genuine past day with 0 contributions ends the streak

    return total, current, longest


def build_svg(days):
    cols = max(d["col"] for d in days) + 1
    width = cols * STEP + 20
    height = 7 * STEP + 20

    rects = []
    for d in days:
        x = 10 + d["col"] * STEP
        y = 10 + d["row"] * STEP
        color = LEVEL_COLORS[d["level"]]
        stroke = f' stroke="{EMPTY_STROKE}" stroke-width="1"' if d["level"] == 0 else ""
        delay = round(d["col"] * 0.02, 2)  # left-to-right reveal
        title = f'{d["count"]} contribution{"s" if d["count"] != 1 else ""} on {d["date"]}'
        rects.append(
            f'<rect x="{x}" y="{y}" width="{CELL}" height="{CELL}" rx="2" ry="2" '
            f'fill="{color}"{stroke} opacity="0">'
            f'<title>{html.escape(title)}</title>'
            f'<animate attributeName="opacity" from="0" to="1" '
            f'begin="{delay}s" dur="0.4s" fill="freeze" '
            f'calcMode="spline" keySplines="0.25 0.1 0.25 1"/>'
            f"</rect>"
        )

    svg = (
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="100%" role="img" aria-label="GitHub contribution graph">'
        f'<rect x="0" y="0" width="{width}" height="{height}" fill="transparent"/>'
        + "".join(rects)
        + "</svg>"
    )
    return svg


def main():
    html_text = fetch_contributions(USERNAME)
    days = parse_days(html_text)
    if not days:
        raise SystemExit("Could not parse contribution data - GitHub markup may have changed.")

    today = find_today(html_text, days)
    total, current, longest = compute_streaks(days, today)
    svg = build_svg(days)

    os.makedirs(os.path.dirname(OUT_SVG), exist_ok=True)
    with open(OUT_SVG, "w") as f:
        f.write(svg)

    print(f"Total contributions (last year): {total}")
    print(f"Current streak: {current} day(s)")
    print(f"Longest streak: {longest} day(s)")
    print(f"Wrote {OUT_SVG}")


if __name__ == "__main__":
    main()
